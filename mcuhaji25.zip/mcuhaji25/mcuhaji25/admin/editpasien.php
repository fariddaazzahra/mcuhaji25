<?php
session_start();
include '../koneksi.php';

// Cek jika pengguna sudah login dan memiliki role admin
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil ID pasien dari URL
$pasien_id = $_GET['id'] ?? 0;
if (!$pasien_id) {
    header("Location: manajemenpasien.php?error=invalid_id");
    exit();
}

// Proses form saat disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nik = trim($_POST['nik']);
    $nama_pasien = trim($_POST['nama_pasien']);
    $tgl_lahir = $_POST['tgl_lahir'];
    $jk_input = isset($_POST['jk']) ? strtoupper(trim($_POST['jk'])) : '';
    // Normalisasi: simpan ke bentuk teks untuk konsistensi grafik dan tampilan
    $jk = ($jk_input === 'L') ? 'Laki-laki' : (($jk_input === 'P') ? 'Perempuan' : '');
    $no_hp = trim($_POST['no_hp']);
    $alamat = trim($_POST['alamat']);
    
    // Data terkait MCU (jika ada)
    $jadwal_id = $_POST['jadwal_id'] ?? null;
    $status_mcu = $_POST['status_mcu'] ?? null;
    $status_bayar = $_POST['status_bayar'] ?? null;
    $jumlah_bayar = $_POST['jumlah_bayar'] ?? 0;

    $conn->begin_transaction();
    try {
        // --- UPDATE DATA PASIEN TERMASUK JENIS KELAMIN ---
        $sql_update = "UPDATE pasien SET 
                       nik = ?, 
                       nama_pasien = ?, 
                       tgl_lahir = ?, 
                       jk = ?, 
                       no_hp = ?, 
                       alamat = ? 
                       WHERE pasien_id = ?";
        
        $stmt_pasien = $conn->prepare($sql_update);
        if (!$stmt_pasien) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt_pasien->bind_param("ssssssi", $nik, $nama_pasien, $tgl_lahir, $jk, $no_hp, $alamat, $pasien_id);
        
        if (!$stmt_pasien->execute()) {
            throw new Exception("Execute failed: " . $stmt_pasien->error);
        }
        
        $affected_rows = $stmt_pasien->affected_rows;
        $stmt_pasien->close();
        
        // Jika ada data jadwal yang ikut di-submit, update juga tabel terkait
        if ($jadwal_id) {
            if ($status_mcu) {
                $stmt_jadwal = $conn->prepare("UPDATE jadwalmcu SET status_mcu=? WHERE jadwal_id=?");
                $stmt_jadwal->bind_param("si", $status_mcu, $jadwal_id);
                $stmt_jadwal->execute();
                $stmt_jadwal->close();
            }
            
            // Cek dulu apakah entri pembayaran sudah ada
            $stmt_check = $conn->prepare("SELECT pembayaran_id FROM pembayaran WHERE jadwal_id = ?");
            $stmt_check->bind_param("i", $jadwal_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            
            if($result_check->num_rows > 0) {
                // Jika sudah ada, UPDATE
                $stmt_bayar = $conn->prepare("UPDATE pembayaran SET status_bayar=?, jumlah=? WHERE jadwal_id=?");
                $stmt_bayar->bind_param("sdi", $status_bayar, $jumlah_bayar, $jadwal_id);
            } else {
                // Jika belum ada, INSERT
                $stmt_bayar = $conn->prepare("INSERT INTO pembayaran (jadwal_id, status_bayar, jumlah, pasien_id) VALUES (?, ?, ?, ?)");
                $stmt_bayar->bind_param("isdi", $jadwal_id, $status_bayar, $jumlah_bayar, $pasien_id);
            }
            $stmt_bayar->execute();
            $stmt_bayar->close();
            $stmt_check->close();
        }
        
        $conn->commit();
        
        // Redirect dengan pesan sukses
        echo "<script>
            window.location.href = 'manajemenpasien.php?update=success';
        </script>";
        exit();
        
    } catch (Exception $e) {
        $conn->rollback();
        $error_message = $e->getMessage();
        echo "<script>
            alert('Gagal update data: " . addslashes($error_message) . "');
            window.location.href = 'editpasien.php?id=$pasien_id&error=update_failed';
        </script>";
        exit();
    }
}

// Query untuk mengambil data lengkap pasien
$stmt = $conn->prepare("
    SELECT p.*, j.jadwal_id, j.tanggal_mcu, j.status_mcu, b.status_bayar, b.jumlah as jumlah_bayar
    FROM pasien p
    LEFT JOIN jadwalmcu j ON p.pasien_id = j.pasien_id
    LEFT JOIN pembayaran b ON j.jadwal_id = b.jadwal_id
    WHERE p.pasien_id = ?
    ORDER BY j.tanggal_mcu DESC LIMIT 1
");
$stmt->bind_param("i", $pasien_id);
$stmt->execute();
$data_pasien = $stmt->get_result()->fetch_assoc();

if (!$data_pasien) {
    header("Location: manajemenpasien.php?error=notfound");
    exit();
}

// Debug: Tampilkan jenis kelamin yang tersimpan
$jk_debug = $data_pasien['jk'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pasien - <?= htmlspecialchars($data_pasien['nama_pasien']) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --dark-green: #0F2A1D; --medium-green-1: #375534; --medium-green-2: #6B9071;
            --light-green: #AEC3B0; --cream: #E3EED4; --white: #FFFFFF;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: linear-gradient(135deg, #E3EED4 0%, #AEC3B0 100%); min-height: 100vh; padding-bottom: 2rem; }
        .sidebar { position: fixed; left: 0; top: 0; width: 260px; height: 100vh; background: linear-gradient(180deg, #0F2A1D 0%, #375534 100%); padding: 2rem 0; box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1); z-index: 1000; overflow-y: auto; }
        .logo-section { text-align: center; padding: 0 1.5rem 2rem; border-bottom: 1px solid rgba(174, 195, 176, 0.3); }
        .logo-icon { width: 70px; height: 70px; background: linear-gradient(135deg, #6B9071, #AEC3B0); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 2rem; margin-bottom: 1rem; box-shadow: 0 6px 20px rgba(107, 144, 113, 0.4); }
        .logo-section h2 { color: #E3EED4; font-size: 1.2rem; font-weight: 600; margin-bottom: 0.3rem; }
        .logo-section p { color: #AEC3B0; font-size: 0.85rem; }
        .user-info { padding: 1.5rem; background: rgba(107, 144, 113, 0.15); margin: 1.5rem; border-radius: 12px; text-align: center; }
        .user-info .avatar { width: 50px; height: 50px; background: linear-gradient(135deg, #AEC3B0, #E3EED4); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 0.5rem; }
        .user-info .name { color: #E3EED4; font-weight: 600; font-size: 0.95rem; }
        .user-info .role { color: #AEC3B0; font-size: 0.8rem; }
        .nav-menu { padding: 1rem 0; }
        .nav-menu a { display: flex; align-items: center; gap: 1rem; padding: 1rem 1.5rem; color: #E3EED4; text-decoration: none; transition: all 0.3s ease; font-size: 0.95rem; border-left: 4px solid transparent; }
        .nav-menu a:hover { background: rgba(174, 195, 176, 0.1); border-left-color: #AEC3B0; padding-left: 2rem; }
        .nav-menu a.active { background: rgba(174, 195, 176, 0.2); border-left-color: #AEC3B0; font-weight: 600; }
        .nav-menu .icon { font-size: 1.2rem; width: 24px; text-align: center; }
        .logout-btn { margin: 1.5rem; padding: 0.9rem; background: linear-gradient(135deg, #ff6b6b, #ee5a6f); color: white; text-align: center; border-radius: 12px; text-decoration: none; display: block; font-weight: 600; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3); cursor: pointer; }
        .logout-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(255, 107, 107, 0.4); }
        .main-content { margin-left: 260px; padding: 2rem; }
        .header { background: white; padding: 2rem; border-radius: 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08); margin-bottom: 2rem; }
        .header h1 { color: #0F2A1D; font-size: 2rem; font-weight: 700; margin-bottom: 0.5rem; }
        .header .subtitle { color: #6B9071; font-size: 0.95rem; }
        .btn { padding: 0.9rem 1.8rem; border: none; border-radius: 12px; font-weight: 600; font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; font-family: 'Poppins', sans-serif; }
        .btn-primary { background: linear-gradient(135deg, #375534, #6B9071); color: #E3EED4; box-shadow: 0 4px 15px rgba(55, 85, 52, 0.3); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(55, 85, 52, 0.4); }
        .btn-secondary { background: #E3EED4; color: #375534; border: 2px solid #AEC3B0; }
        .btn-secondary:hover { background: #AEC3B0; }
        .detail-card { background: white; padding: 2.5rem; border-radius: 20px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08); margin-bottom: 2rem; }
        .detail-card h3 { color: var(--dark-green); font-size: 1.2rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 0.75rem;}
        .detail-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; }
        .detail-item { display: flex; flex-direction: column; }
        .detail-label { font-weight: 600; color: var(--dark-green); margin-bottom: 0.75rem; font-size: 0.9rem; }
        .form-input, select { width: 100%; padding: 0.9rem 1.2rem; border: 2px solid #AEC3B0; border-radius: 12px; font-size: 0.95rem; font-family: 'Poppins', sans-serif; transition: all 0.3s ease; background-color: #F8FBF6; }
        .form-input:focus, select:focus { outline: none; border-color: #6B9071; box-shadow: 0 0 0 4px rgba(107, 144, 113, 0.1); }
        select { cursor: pointer; appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%236B9071' d='M6 9L1 4h10z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 1rem center; padding-right: 2.5rem; }
        .form-actions { display: flex; justify-content: flex-end; gap: 1rem; margin-top: -1rem; }
        textarea.form-input { resize: vertical; min-height: 100px; }
        .debug-info { background: #fff3cd; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.85rem; color: #856404; }
        @media (max-width: 968px) { .sidebar { transform: translateX(-100%); } .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo-section"><div class="logo-icon">🕌</div><h2>MCU Haji</h2><p>Sistem Informasi</p></div>
        <div class="user-info">
            <div class="avatar">👑</div>
            <div class="name"><?= htmlspecialchars($_SESSION['username']) ?></div>
            <div class="role">Admin</div>
        </div>
        <nav class="nav-menu">
            <a href="dashboardadmin.php"><span class="icon">📊</span><span>Dashboard</span></a>
            <a href="manajemenpasien.php" class="active"><span class="icon">👥</span><span>Manajemen Pasien</span></a>
            <a href="manajemenmcu.php"><span class="icon">🩺</span><span>Manajemen MCU</span></a>
        </nav>
        <a href="#" onclick="confirmLogout(event)" class="logout-btn">🚪 Logout</a>
    </aside>

   <main class="main-content">
        <div class="header">
            <h1>Edit Data Pasien</h1>
            <p class="subtitle">Perbarui biodata dan status terkait pasien.</p>
        </div>

        <!-- Debug tersembunyi di console -->
        <script>
            console.log('Debug Info - Jenis Kelamin saat ini:', '<?= htmlspecialchars($jk_debug) ?>');
        </script>

        <form method="POST" action="editpasien.php?id=<?= $pasien_id ?>" id="editForm">
            <input type="hidden" name="jadwal_id" value="<?= htmlspecialchars($data_pasien['jadwal_id'] ?? '') ?>">
            
            <div class="detail-card">
                <h3>👤 Informasi Personal</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label for="nama_pasien" class="detail-label">Nama Lengkap</label>
                        <input type="text" id="nama_pasien" name="nama_pasien" class="form-input" value="<?= htmlspecialchars($data_pasien['nama_pasien']) ?>" required>
                    </div>
                    <div class="detail-item">
                        <label for="nik" class="detail-label">NIK</label>
                        <input type="text" id="nik" name="nik" class="form-input" value="<?= htmlspecialchars($data_pasien['nik']) ?>" required>
                    </div>
                    <div class="detail-item">
                        <label for="tgl_lahir" class="detail-label">Tanggal Lahir</label>
                        <input type="date" id="tgl_lahir" name="tgl_lahir" class="form-input" value="<?= htmlspecialchars($data_pasien['tgl_lahir']) ?>" required>
                    </div>
                    <div class="detail-item">
                        <label for="jk" class="detail-label">Jenis Kelamin</label>
                        <select id="jk" name="jk" class="form-input" required>
                            <option value="">-- Pilih --</option>
                            <option value="L" <?= (strtoupper($data_pasien['jk']) == 'L') ? 'selected' : '' ?>>Laki-laki</option>
                            <option value="P" <?= (strtoupper($data_pasien['jk']) == 'P') ? 'selected' : '' ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="detail-item">
                        <label for="no_hp" class="detail-label">No. Handphone</label>
                        <input type="text" id="no_hp" name="no_hp" class="form-input" value="<?= htmlspecialchars($data_pasien['no_hp']) ?>" required>
                    </div>
                    <div class="detail-item" style="grid-column: 1 / -1;">
                        <label for="alamat" class="detail-label">Alamat</label>
                        <textarea id="alamat" name="alamat" rows="3" class="form-input" required><?= htmlspecialchars($data_pasien['alamat']) ?></textarea>
                    </div>
                </div>
            </div>

            <?php if (isset($data_pasien['jadwal_id'])): ?>
            <div class="detail-card">
                <h3>🕒 Status Terakhir</h3>
                <div class="detail-grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
                    <div class="detail-item">
                        <label for="status_mcu" class="detail-label">Status MCU</label>
                        <select id="status_mcu" name="status_mcu" class="form-input">
                            <option value="dijadwalkan" <?= (strtolower($data_pasien['status_mcu']) == 'dijadwalkan') ? 'selected' : '' ?>>Dijadwalkan</option>
                            <option value="selesai" <?= (strtolower($data_pasien['status_mcu']) == 'selesai') ? 'selected' : '' ?>>Selesai</option>
                        </select>
                    </div>
                    <div class="detail-item">
                        <label for="status_bayar" class="detail-label">Status Bayar</label>
                        <select id="status_bayar" name="status_bayar" class="form-input">
                            <option value="">-- Pilih --</option>
                            <option value="Lunas" <?= (strtolower($data_pasien['status_bayar'] ?? '') == 'lunas') ? 'selected' : '' ?>>Lunas</option>
                            <option value="Belum Bayar" <?= (strtolower($data_pasien['status_bayar'] ?? '') == 'belum bayar') ? 'selected' : '' ?>>Belum Bayar</option>
                        </select>
                    </div>
                    <div class="detail-item">
                        <label for="jumlah_bayar" class="detail-label">Jumlah Bayar (Rp)</label>
                        <input type="number" id="jumlah_bayar" name="jumlah_bayar" class="form-input" value="<?= htmlspecialchars($data_pasien['jumlah_bayar'] ?? '0') ?>" placeholder="cth: 500000">
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="form-actions">
                <a href="manajemenpasien.php" class="btn btn-secondary">❌ Batal</a>
                <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
            </div>
        </form>
    </main>
<script>
function confirmLogout(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Konfirmasi Logout', text: "Apakah Anda yakin ingin keluar?", icon: 'question',
        iconColor: '#AEC3B0', showCancelButton: true, confirmButtonColor: '#d33',
        cancelButtonColor: '#375534', confirmButtonText: 'Ya, Logout!', cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) { window.location.href = '../logout.php'; }
    });
}

// Debug form submit
document.getElementById('editForm').addEventListener('submit', function(e) {
    const jk = document.getElementById('jk').value;
    console.log('Form submitted with JK:', jk);
    
    if (!jk) {
        e.preventDefault();
        Swal.fire({
            icon: 'error',
            title: 'Jenis Kelamin Harus Dipilih!',
            text: 'Silakan pilih jenis kelamin sebelum menyimpan.'
        });
    }
});
</script>
</body>
</html>