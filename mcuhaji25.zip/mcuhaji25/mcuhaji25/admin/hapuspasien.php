<?php
session_start();
include '../koneksi.php';

// Hanya Admin yang bisa mengakses file ini
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil ID pasien dari URL
$pasien_id = $_GET['id'] ?? 0;
if (!$pasien_id) {
    // Jika tidak ada ID, kembali dengan pesan error
    header("Location: manajemenpasien.php?error=invalid_id");
    exit();
}

// Mulai transaksi database untuk memastikan semua data terhapus dengan aman
$conn->begin_transaction();

try {
    // 1. Ambil semua jadwal_id yang terkait dengan pasien ini
    $jadwal_ids = [];
    $stmt_get_jadwal = $conn->prepare("SELECT jadwal_id FROM jadwalmcu WHERE pasien_id = ?");
    $stmt_get_jadwal->bind_param("i", $pasien_id);
    $stmt_get_jadwal->execute();
    $result_jadwal = $stmt_get_jadwal->get_result();
    while($row = $result_jadwal->fetch_assoc()) {
        $jadwal_ids[] = $row['jadwal_id'];
    }
    $stmt_get_jadwal->close();

    // 2. Jika pasien memiliki riwayat jadwal, hapus data terkait di tabel lain
    if (!empty($jadwal_ids)) {
        $id_list = implode(',', $jadwal_ids); // Membuat string seperti '1,2,3'

        // Hapus dari tabel anak terlebih dahulu untuk menghindari error foreign key
        $conn->query("DELETE FROM pembayaran WHERE jadwal_id IN ($id_list)");
        $conn->query("DELETE FROM pempenunjang WHERE jadwal_id IN ($id_list)");
        $conn->query("DELETE FROM hasilmcu WHERE jadwal_id IN ($id_list)");
    }

    // 3. Hapus dari tabel jadwalmcu
    $stmt_jadwal = $conn->prepare("DELETE FROM jadwalmcu WHERE pasien_id = ?");
    $stmt_jadwal->bind_param("i", $pasien_id);
    $stmt_jadwal->execute();
    $stmt_jadwal->close();
    
    // 4. Terakhir, setelah semua data terkait terhapus, hapus data utama di tabel pasien
    $stmt_pasien = $conn->prepare("DELETE FROM pasien WHERE pasien_id = ?");
    $stmt_pasien->bind_param("i", $pasien_id);
    $stmt_pasien->execute();
    $stmt_pasien->close();
    
    // Jika semua proses di atas berhasil, simpan perubahan
    $conn->commit();
    // Kembali ke halaman manajemen pasien dengan notifikasi sukses
    header("Location: manajemenpasien.php?delete=success");
    exit();

} catch (Exception $e) {
    // Jika ada satu saja proses yang gagal, batalkan semua perubahan
    $conn->rollback();
    // Kembali dengan notifikasi error
    header("Location: manajemenpasien.php?error=delete_failed");
    exit();
}
?>